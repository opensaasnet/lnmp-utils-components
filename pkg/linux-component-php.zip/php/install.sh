#!/bin/bash

#iconv http://ftp.gnu.org/pub/gnu/libiconv/libiconv-1.16.tar.gz
#mcrypt http://nchc.dl.sourceforge.net/project/mcrypt/MCrypt/2.6.8/mcrypt-2.6.8.tar.gz
#http://sourceforge.net/projects/mhash/files/mhash/

#php http://cn2.php.net/distributions/php-5.6.27.tar.gz
#https://libzip.org/download/libzip-1.5.2.tar.gz

_COM_VERSION="php-7.3.10"


com_init "${_COM_VERSION}.tar.gz"
yum_install readline-devel bzip2-devel curl-devel gmp-devel libxml2-devel libxslt-devel libmemcached libmemcached-devel pcre pcre-devel libjpeg libjpeg-devel libpng libpng-devel libpng libpng-devel gd gd-devel freetype freetype-devel libxml2 libxml2-devel zlib zlib-devel glib2 glib2-devel bzip2 bzip2-devel libevent libevent-devel ncurses ncurses-devel curl curl-devel e2fsprogs e2fsprogs-devel krb5 krb5-devel libidn libidn-devel openssl openssl-devel vim-minimal nano fonts-chinese gettext gettext-devel ncurses-devel gmp-devel pspell-devel  unzip  popt-devel popt-static

_ICONV_VERSION="libiconv-1.16"
_LIBMCRYPT_VERSION="libmcrypt-2.5.8"
_MHASH_VERSION="mhash-0.9.9.9"
_MCRYPT_VERSION="mcrypt-2.6.8"
_IGBINARY_VERSION="igbinary-2.0.8"
_CMAKE_VERSION="cmake-3.15.4"
_ZIP_VERSION="libzip-1.5.2"
_MEMCACHED_VERSION="memcached-3.1.3"
_MONGO_VERSION="mongodb-1.5.5"
_REDIS_VERSION="redis-5.0.0"

#TINY_CN 

#PHP及各组件源码路径
_ICONV_SOURCE_FILE="$COM_PACKAGE_DIR$_ICONV_VERSION.tar.gz"
_MCRYPT_SOURCE_FILE="$COM_PACKAGE_DIR/$_MCRYPT_VERSION.tar.gz"
_LIBMCRYPT_SOURCE_FILE="$COM_PACKAGE_DIR/$_LIBMCRYPT_VERSION.tar.gz"
_MHASH_SOURCE_FILE="$COM_PACKAGE_DIR/$_MHASH_VERSION.tar.gz"

_MEMCACHED_SOURCE_FILE="$COM_PACKAGE_DIR/$_MEMCACHED_VERSION.tgz"
_MONGO_SOURCE_FILE="$COM_PACKAGE_DIR/$_MONGO_VERSION.tgz"
_REDIS_SOURCE_FILE="$COM_PACKAGE_DIR/$_REDIS_VERSION.tgz"
_IGBINARY_SOURCE_FILE="$COM_PACKAGE_DIR/$_IGBINARY_VERSION.tgz"
_CMAKE_SOURCE_FILE="$COM_PACKAGE_DIR/$_CMAKE_VERSION.tar.gz"
_ZIP_SOURCE_FILE="$COM_PACKAGE_DIR/$_ZIP_VERSION.tar.gz"

com_pkg_check  "$_ICONV_SOURCE_FILE" $_LIBMCRYPT_SOURCE_FILE $_MCRYPT_SOURCE_FILE $_MHASH_SOURCE_FILE $_MEMCACHED_SOURCE_FILE $_MONGO_SOURCE_FILE $_ZIP_SOURCE_FILE $_CMAKE_SOURCE_FILE 

com_init "${_COM_VERSION}.tar.gz"

createdir $COM_DATA_LOG_DIR
createdir $COM_DATA_CONF_DIR


if [ ! -f /usr/local/bin/iconv ];then
    com_untar $_ICONV_SOURCE_FILE
    cd $TMP_COM_DIR/$_ICONV_VERSION
    ./configure
    cd srclib/
    sed -i -e '/gets is a security/d' ./stdio.in.h
    cd ../
    make  && make install
fi

if [ ! -f /usr/local/lib/libmcrypt.so ];then
    com_untar $_LIBMCRYPT_SOURCE_FILE
    cd $TMP_COM_DIR/$_LIBMCRYPT_VERSION
    ./configure 
    make && make install        
    ldconfig >>/dev/null

    com_untar $_MCRYPT_SOURCE_FILE
    cd $TMP_COM_DIR/$_MCRYPT_VERSION
    ./configure --with-libmcrypt-prefix=/usr/local
    make  && make install 
fi

if [ ! -f /usr/local/lib/libmhash.so ];then
    com_untar $_MHASH_SOURCE_FILE
    cd $TMP_COM_DIR/$_MHASH_VERSION
    ./configure
    make  && make install
fi

#cmake 3.15
if [ ! -f /usr/local/bin/cmake ] || [ `/usr/local/bin/cmake --version|grep "3.15"|wc -l` -eq 0 ]; then
	com_untar $_CMAKE_SOURCE_FILE
	cd $TMP_COM_DIR/$_CMAKE_VERSION
	./bootstrap
	make -j $CPU_NUM && make install
fi

if [ ! -f "/usr/local/lib/libzip.so.5.0" ];then
    com_untar $_ZIP_SOURCE_FILE
    cd $TMP_COM_DIR/$_ZIP_VERSION
	mkdir build 
	cd ./build
    cmake ../
    #cd ../
    make  && make install
fi

ldconfig -v>/dev/null

com_untar $COM_SOURCE_FILE
cd $TMP_COM_DIR/$_COM_VERSION
./configure --prefix=$COM_INSTALL_DIR --with-config-file-path=${COM_INSTALL_DIR}etc --enable-fpm --with-fpm-user=www --with-fpm-group=www --enable-inline-optimization --disable-rpath --disable-debug --enable-shared --enable-soap --with-libxml-dir --enable-xml --with-xmlrpc --with-openssl --with-mcrypt --with-mhash --with-pcre-regex --with-sqlite3 --with-zlib  --enable-bcmath --with-iconv --with-bz2 --enable-calendar --with-curl --with-cdb --enable-dom --enable-exif --enable-fileinfo --enable-filter --with-pcre-dir --enable-ftp --with-gd --with-openssl-dir --with-jpeg-dir --with-png-dir --with-zlib-dir --with-freetype-dir --enable-gd-native-ttf --enable-gd-jis-conv --with-gettext --with-gmp --with-mhash --enable-json --enable-mbstring --enable-mbregex --enable-mbregex-backtrack --with-libmbfl --with-onig --enable-pdo --with-mysqli=mysqlnd --with-pdo-mysql=mysqlnd --with-pdo-sqlite --with-readline --enable-session --enable-shmop --enable-simplexml --enable-sockets --enable-sysvmsg --enable-sysvsem --enable-sysvshm --enable-wddx --with-libxml-dir --with-xsl --enable-zip --enable-mysqlnd-compression-support --with-pear --enable-opcache --enable-phar  --enable-dba --enable-pcntl  --enable-sockets --enable-zip  --with-snmp  --with-ssh2 

make -j $CPU_NUM ZEND_EXTRA_LIBS='-liconv'
if [ -e "$COM_INSTALL_DIR" ];then
rm -rf "$COM_INSTALL_DIR"
fi
make install

if [ ! -d $COM_INSTALL_DIR ];then
        error "$_COM_VERSION安装失败！"
fi

_ini_file=${COM_INSTALL_DIR}etc/php.ini
_conf_file=${COM_INSTALL_DIR}etc/php-fpm.conf 
_www_conf_file=${COM_INSTALL_DIR}etc/php-fpm.d/www.conf

cp ${COM_INSTALL_DIR}etc/php-fpm.d/www.conf.default $_www_conf_file
cp $COM_INSTALL_DIR/etc/php-fpm.conf.default $_conf_file
cp php.ini-production $_ini_file
cp sapi/fpm/init.d.php-fpm /etc/init.d/php-fpm
chmod 777 /etc/init.d/php-fpm
chkconfig --level 345 php-fpm on


_dl=${COM_DATA_LOG_DIR//\//\\\/}


 
sed -i 's/;pid = run\/php-fpm.pid/pid = run\/php-fpm.pid/g' $_conf_file
sed -i "s/;error_log = log\/php-fpm.log/error_log = ${_dl}php-fpm.log/g" $_conf_file
sed -i "s/;events.mechanism = epoll/events.mechanism = epoll/g" $_conf_file
sed -i "s/pm.max_children = 5$/pm.max_children = 512/g" $_www_conf_file
sed -i "s/pm.start_servers = 2$/pm.start_servers = 24/g" $_www_conf_file
sed -i "s/pm.min_spare_servers = 1/pm.min_spare_servers = 8/g" $_www_conf_file
sed -i "s/pm.max_spare_servers = 3/pm.max_spare_servers = 64/g" $_www_conf_file 
        
#配置PHP.ini
sed -i "s/short_open_tag = Off/short_open_tag = On/g" $_ini_file
sed -i "s/error_reporting = E_ALL \& ~E_DEPRECATED/error_reporting = E_ALL \& ~E_NOTICE \| E_STRICT/g"  $_ini_file
sed -i "s/upload_max_filesize = 2M/upload_max_filesize = 50M/g" $_ini_file
sed -i "s/display_errors = Off/display_errors = On/g" $_ini_file
sed -i "s/;date.timezone =/date.timezone = PRC/g" $_ini_file

sed -i "s/;opcache.enable=0/opcache.enable=1/g" $_ini_file
sed -i "s/;opcache.enable_cli=0/opcache.enable_cli=1/g" $_ini_file
sed -i "s/;opcache.memory_consumption=64/opcache.memory_consumption=64/g" $_ini_file
sed -i "s/;opcache.interned_strings_buffer=4/opcache.interned_strings_buffer=8/g" $_ini_file
sed -i "s/;opcache.max_accelerated_files=2000/opcache.max_accelerated_files=8000/g" $_ini_file
sed -i "s/;opcache.revalidate_freq=2/opcache.revalidate_freq=1/g" $_ini_file
sed -i "s/;opcache.fast_shutdown=0/opcache.fast_shutdown=1/g" $_ini_file  
 
     
ln -s $COM_INSTALL_DIR/bin/php /usr/bin/php 
ln -s $COM_INSTALL_DIR/bin/phpize /usr/bin/phpize
ln -s $COM_INSTALL_DIR/sbin/php-fpm /usr/bin/php-fpm        
service php-fpm restart

com_untar $_MEMCACHED_SOURCE_FILE
cd $TMP_COM_DIR/$_MEMCACHED_VERSION
phpize
./configure --with-php-config=$COM_INSTALL_DIR/bin/php-config
make && make install 

com_untar $_MONGO_SOURCE_FILE
cd $TMP_COM_DIR/$_MONGO_VERSION
phpize
./configure --with-php-config=$COM_INSTALL_DIR/bin/php-config 
make && make install

com_untar $_IGBINARY_SOURCE_FILE
cd $TMP_COM_DIR/$_IGBINARY_VERSION
phpize
./configure --with-php-config=$COM_INSTALL_DIR/bin/php-config 
make && make install

com_untar $_REDIS_SOURCE_FILE
cd $TMP_COM_DIR/$_REDIS_VERSION
phpize
./configure --enable-redis-igbinary --with-php-config=$COM_INSTALL_DIR/bin/php-config 
make && make install
             
#com_untar $_LOADER_SOURCE_FILE
#cd $TMP_COM_DIR/$_LOADER_VERSION

cat >>$_ini_file<<EOF
extension = igbinary.so
extension = mongodb.so
extension = redis.so
extension = memcached.so 
EOF

service php-fpm stop
service php-fpm start
  



