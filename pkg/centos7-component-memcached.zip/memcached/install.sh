#!/bin/bash

#http://www.memcached.org/files/memcached-1.5.19.tar.gz

_COM_VERSION="memcached-1.5.19"

user_add 'memcached'
yum_install "libevent-devel"
yum_uninstall 'memcached'

com_init "${_COM_VERSION}.tar.gz"
com_untar $COM_SOURCE_FILE

createdir ${COM_DATA_CONF_DIR}

cd $TMP_COM_DIR/$_COM_VERSION
./configure --prefix=$COM_INSTALL_DIR
make && make install

_COM_SERVICE_DIR=/usr/lib/systemd/system/memcached.service
cp -f ${COM_CONF_DIR}memcached.service $_COM_SERVICE_DIR
com_replace $_COM_SERVICE_DIR

_COM_CONF_DIR=${COM_DATA_CONF_DIR}memcached.conf
cp -f ${COM_CONF_DIR}memcached.conf $_COM_CONF_DIR
com_replace $_COM_CONF_DIR 

com_install_test $_COM_SERVICE_DIR $_COM_CONF_DIR

systemctl daemon-reload
systemctl start memcached
systemctl stop memcached
systemctl start memcached       