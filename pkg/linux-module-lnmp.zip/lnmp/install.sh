#!/bin/bash

PROJECT_DIR=$DATA_WEB_DIR"saasjit/tinyphp/"
if [ -d $PROJECT_DIR ];then
	echo "${PROJECT_DIR} is exists and exit!"
	exit
fi

if [ ! -d $PROJECT_DIR ];then
	mkdir -p $PROJECT_DIR
fi
#安装必需组件
require  mysql php openresty redis

#init mysql database
if [ -d "${INSTALL_DIR}mysql" ] && [ -f /tmp/mysql.sock ];then
	mysql -uroot -hlocalhost <<EOF
CREATE DATABASE saasjit_tinyphp;
EOF
fi

#init tinyphp
if [ -d "${INSTALL_DIR}php" ];then
	cd $PROJECT_DIR
	composer create-project saasjit/tinyphp ./ @dev
	if [ -d "${PROJECT_DIR}runtime/" ];then
		chmod 777 -R ${PROJECT_DIR}runtime/
	fi
	if [ -d "${PROJECT_DIR}application/runtime/" ];then
		chmod 777 -R ${PROJECT_DIR}application/runtime/
	fi
	if [ -f ${PROJECT_DIR}"composer.json" ];then
		composer install
	fi
fi

#init nginx.conf
if [ -d /usr/local/openresty ];then
	\cp -f $MOD_CONF_DIR/def.conf /data/conf/openresty/def.conf
	service openresty restart
fi