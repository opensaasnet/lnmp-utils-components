#!/bin/bash
# wget  https://codeload.github.com/happyfish100/fastdfs/tar.gz/V6.01
# https://codeload.github.com/happyfish100/fastdfs/tar.gz/refs/tags/V6.07
# https://codeload.github.com/happyfish100/libfastcommon/tar.gz/refs/tags/V1.0.53

_COM_VERSION="fastdfs-6.07"

_LIBCOMMON_VERSION="libfastcommon-1.0.53"
_LIBCOMMON_FILE="${COM_PACKAGE_DIR}${_LIBCOMMON_VERSION}.tar.gz"

com_untar $_LIBCOMMON_FILE

cd "${TMP_COM_DIR}${_LIBCOMMON_VERSION}"
./make.sh
./make.sh install

com_init "${_COM_VERSION}.tar.gz"
com_untar  $COM_SOURCE_FILE

cd "${TMP_COM_DIR}${_COM_VERSION}"


./make.sh
./make.sh install

STORAGE_DIR=$DATA_DFS_DIR"storage/"
STORAGE_DIR_0=$STORAGE_DIR"s0/"
STORAGE_DIR_1=$STORAGE_DIR"s1/"
#STORAGE_DIR_2=$STORAGE_DIR"s2/"
#STORAGE_DIR_3=$STORAGE_DIR"s3/"

TRACKER_DIR=$DATA_DFS_DIR"tracker/"
CLIENT_DIR=$DATA_DFS_DIR"client/"
createdir $COM_DATA_LOG_DIR
createdir $COM_DATA_CONF_DIR     
createdir $DATA_DFS_DIR $STORAGE_DIR $STORAGE_DIR_0 $STORAGE_DIR_1 $STORAGE_DIR_2 $STORAGE_DIR_3 $TRACKER_DIR $CLIENT_DIR

chmod 777 -R $DATA_DFS_DIR

cp $TMP_COM_DIR/$_COM_VERSION/conf/http.conf /etc/fdfs/http.conf
cp $TMP_COM_DIR/$_COM_VERSION/conf/mime.types   /etc/fdfs/mime.types
cp /etc/fdfs/client.conf.sample /etc/fdfs/client.conf
cp /etc/fdfs/storage.conf.sample  /etc/fdfs/storage.conf
cp /etc/fdfs/storage_ids.conf.sample  /etc/fdfs/storage_ids.conf
cp /etc/fdfs/tracker.conf.sample /etc/fdfs/tracker.conf

_TRACKER_IP_DEFAULT="172.17.0.2"
echo "需要更改/etc/fdfs/storage.conf的tracker_server地址为非127.0.0.1的外网IP(default:${_TRACKER_IP_DEFAULT}):"
read _TRACKER_IP
if [ "$_TRACKER_IP" = "" ];then
	_TRACKER_IP=$_TRACKER_IP_DEFAULT
fi

_DPATH=${DATA_DFS_DIR//\//\\\/}
#storage
sed -i "s/base_path = \/home\/yuqing\/fastdfs/base_path = ${_DPATH}storage/g" /etc/fdfs/storage.conf
sed -i "s/store_path0 = \/home\/yuqing\/fastdfs/store_path0 = ${_DPATH}storage\/s0/g" /etc/fdfs/storage.conf
sed -i "s/#store_path1 = \/home\/yuqing\/fastdfs2/store_path1 = ${_DPATH}storage\/s1/g" /etc/fdfs/storage.conf
sed -i "s/subdir_count_per_path = 256/subdir_count_per_path = 32/g" /etc/fdfs/storage.conf
sed -i "s/tracker_server = 192\.168\.209\.121\:22122/tracker_server = ${_TRACKER_IP}\:22122/g" /etc/fdfs/storage.conf
sed -i "s/tracker_server = 192\.168\.209\.122\:22122/#tracker_server = 192\.168\.209\.122\:22122/g" /etc/fdfs/storage.conf

#tracker
sed -i "s/base_path = \/home\/yuqing\/fastdfs/base_path = ${_DPATH}tracker/g" /etc/fdfs/tracker.conf

#client
sed -i "s/base_pat = \/home\/yuqing\/fastdfs/base_path=$_DPATH\/client/g" /etc/fdfs/client.conf
sed -i "s/tracker_server = 192\.168\.0\.196\:22122/tracker_server = ${_TRACKER_IP}:22122/g" /etc/fdfs/client.conf
sed -i "s/tracker_server = 192\.168\.0\.197\:22122/#tracker_server = 192\.168\.0\.197\:22122/g" /etc/fdfs/client.conf

#storage_ids
sed -i "s/100001   group1  192.168.0.196/100001   group1  127.0.0.1/g" /etc/fdfs/storage_ids.conf
sed -i "s/100002   group1  192.168.0.197/#100002   group1  192.168.0.197/g" /etc/fdfs/storage_ids.conf

chkconfig --level 345 fdfs_storaged on
chkconfig --level 345 fdfs_trackerd on
killport 22122 
killport 23000

service fdfs_storaged stop
service fdfs_trackerd stop
service fdfs_trackerd start
service fdfs_storaged start
service fdfs_storaged restart
service fdfs_trackerd restart