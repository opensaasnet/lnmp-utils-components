#!/bin/bash

# memcached: http://www.memcached.org/files/memcached-1.6.12.tar.gz

_COM_VERSION="memcached-1.6.12"

user_add 'memcached'
yum_uninstall 'memcached'

com_init "${_COM_VERSION}.tar.gz"
com_untar $COM_SOURCE_FILE

createdir ${COM_DATA_CONF_DIR}

cd $TMP_COM_DIR/$_COM_VERSION
./configure --prefix=$COM_INSTALL_DIR
make && make install

#config
_COM_SERVICE_FILE=/usr/lib/systemd/system/memcached.service
cp -f ${COM_CONF_DIR}memcached.service $_COM_SERVICE_FILE
com_replace $_COM_SERVICE_FILE

_COM_CONF_FILE=${COM_DATA_CONF_DIR}memcached.conf
cp -f ${COM_CONF_DIR}memcached.conf $_COM_CONF_FILE
com_replace $_COM_CONF_FILE

com_install_test $_COM_SERVICE_FILE $_COM_CONF_FILE

systemctl daemon-reload
systemctl start memcached
systemctl stop memcached
systemctl start memcached       