#!/bin/bash
#openresty https://openresty.org/download/openresty-1.19.3.2.tar.gz
#drizzle http://agentzh.org/misc/nginx/drizzle7-2011.07.21.tar.gz
#nginx-upload-module update https://codeload.github.com/fdintino/nginx-upload-module/zip/2.3
#wget https://codeload.github.com/happyfish100/fastdfs-nginx-module/zip/master
#wget https://codeload.github.com/happyfish100/libfastcommon/zip/master
#yuminstall pcre-devel openssl-devel gcc
#https://codeload.github.com/chobits/ngx_http_proxy_connect_module/zip/master

if [ `hasoption "fdfs"` = "1" ]; then
    if [ ! -d /etc/fdfs ]; then
        echo "Fastdfs needs to be installed first: (y/n)"
        read is_require_fastdfs
        if [ $is_require_fastdfs = "y" ] || [ $is_require_fastdfs = "Y" ]; then
        	require fastdfs;
        else 
        	error "compoent instalition failed: Fastdfs needs to be installed first!";	
        fi
    fi
fi

yum_install gd-devel pcre-devel openssl-devel

_COM_VERSION="openresty-1.19.3.2"

_UPLOAD_VERSION="nginx-upload-module-2.3.0"
_UPLOAD_FILE="${COM_PACKAGE_DIR}${_UPLOAD_VERSION}.tar.gz"

_PROXY_VERSION="ngx_http_proxy_connect_module-0.0.2"
_PROXY_FILE="${COM_PACKAGE_DIR}${_PROXY_VERSION}.tar.gz"

_FDFS_VERSION="fastdfs-nginx-module-1.22"
_FDFS_FILE="${COM_PACKAGE_DIR}${_FDFS_VERSION}.tar.gz"


com_init "$_COM_VERSION.tar.gz"
com_untar  $COM_SOURCE_FILE

_NGINX_EXT_STR=""
if [ `hasoption "fdfs"` = "1" ]; then

	echo "add module[fastdfs, upload] to nginx！"
	
	# upload
	com_untar "${_UPLOAD_FILE}"
	_TO_DIR="${TMP_COM_DIR}/${_COM_VERSION}/bundle/nginx_upload_module"
	if [ -d "${_TO_DIR}" ];then
    	rm -rf $_TO_DIR
	fi
	mv "${TMP_COM_DIR}${_UPLOAD_VERSION}"  $_TO_DIR
	
	# fdfs
	com_untar "${_FDFS_FILE}"
	_TO_DIR="${TMP_COM_DIR}/${_COM_VERSION}/bundle/fastdfs-nginx-module"
	if [ -d "${_TO_DIR}" ];then
    	rm -rf $_TO_DIR
	fi

	_MFCONF="/etc/fdfs/mod_fastdfs.conf"
	cp ${TMP_COM_DIR}${_FDFS_VERSION}/src/mod_fastdfs.conf $_MFCONF
	mv ${TMP_COM_DIR}${_FDFS_VERSION} $_TO_DIR

	MOD_DIR=$DATA_DFS_DIR"mod/"
	createdir $MOD_DIR
	
	_MPATH=${MOD_DIR//\//\\\/}
	_DPATH=${DATA_DFS_DIR//\//\\\/}

	sed -i "s/base_path=\/tmp/base_path=${_MPATH}/g" $_MFCONF
	sed -i "s/store_path0=\/home\/yuqing\/fastdfs/store_path0=${_DPATH}storage\/s0/g" $_MFCONF
	sed -i "s/#store_path1=\/home\/yuqing\/fastdfs1/store_path1=${_DPATH}storage\/s1/g" $_MFCONF
	sed -i "s/tracker\:22122/tracker_server=127.0.0.1\:22122/g" $_MFCONF
	_NGINX_EXT_STR="--add-module=bundle/nginx_upload_module --add-module=bundle/fastdfs-nginx-module/src"
fi

# -o proxy
if [ `hasoption "proxy"` = "1" ];then

	echo "add module [proxy] to nginx"
	com_untar $_PROXY_FILE
	_TO_DIR="${TMP_COM_DIR}/${_COM_VERSION}/bundle/ngx_http_proxy_connect_module"

	mv "${TMP_COM_DIR}${_PROXY_VERSION}" $_TO_DIR
	cd "${TMP_COM_DIR}/${_COM_VERSION}/bundle/nginx-1.19.3"
	patch -p1 < "${TMP_COM_DIR}/${_COM_VERSION}/bundle/ngx_http_proxy_connect_module/patch/proxy_connect_rewrite_1018.patch"
	_NGINX_EXT_STR=" --add-module=bundle/ngx_http_proxy_connect_module "$_EXT_STR
fi



cd "${TMP_COM_DIR}/${_COM_VERSION}"
./configure  --with-luajit  --with-http_iconv_module  --with-http_image_filter_module --with-http_ssl_module --with-http_v2_module --with-http_stub_status_module  --with-http_slice_module $_NGINX_EXT_STR
make
make install

WWW_DIR=$DATA_WEB_DIR"www"

createdir $COM_DATA_LOG_DIR
createdir $COM_DATA_CONF_DIR
createdir $WWW_DIR

cp -f $COM_CONF_DIR"def.conf" $COM_DATA_CONF_DIR
if [ ! -f $COM_INSTALL_DIR"nginx/conf/openresty.conf" ];then
	cp -f $COM_CONF_DIR"nginx.conf" $COM_INSTALL_DIR"nginx/conf/openresty.conf"
fi

cp -f $COM_CONF_DIR"openresty"  /etc/init.d/openresty

grep "^#patch by opensaasnet/lnmp-utils$" "${COM_INSTALL_DIR}nginx/conf/fastcgi.conf" >/dev/null
if [ $? != 0 ]; then

	cat >>"${COM_INSTALL_DIR}nginx/conf/fastcgi.conf"<<EOF
#patch by opensaasnet/lnmp-utils	
fastcgi_split_path_info ^((?U).+\.php)(/?.+)$;
fastcgi_param  PATH_INFO        \$fastcgi_path_info;
fastcgi_param  SCRIPT_FILENAME  \$document_root\$fastcgi_script_name;
EOF

fi

#FASTDFS SO安装
if [ `hasoption "fdfs"` = "1" ]; then
    /usr/bin/gcc -I/usr/include/fastdfs -I/usr/include/fastcommon -I${COM_INSTALL_DIR}luajit/include/luajit-2.1 ${COM_CONF_DIR}fdfs.c -fPIC -shared -o ${COM_INSTALL_DIR}lualib/fdfs.so
fi

chmod +x /etc/init.d/openresty
chkconfig --level 345 openresty on

killport 80

service openresty start
service openresty restart
service openresty stop
service openresty start
