/**
* Copyright (C) 2013 King@tinycn.com
*
**/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "fdfs_client.h"

#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"
#include "luajit.h"


static void usage(char *argv[])
{
    printf("Usage: %s <config_filename> <local_filename> " \
        "[storage_ip:port] [store_path_index]\n", argv[0]);
}

/**
* 返回值组装
* param int status 错误状态
* param char* str 返回正确的值或错误内容
* return void 没有返回值
*/
static void ret(int status, char *str, lua_State *L) {
    lua_pushnumber(L, status);
    lua_pushstring(L, str);
}

/**
* 根据文件路径上传文件
* param char* conf_filename 配置文件
* param
*/
static int upload_file(char *conf_filename, char *local_filename,char *ext_name, lua_State *L)
{
    char group_name[FDFS_GROUP_NAME_MAX_LEN + 1];
    ConnectionInfo *pTrackerServer;
    int result;
    int store_path_index;
    ConnectionInfo storageServer;
    char file_id[512];
    char ret_str[512];
    if ((result=fdfs_client_init(conf_filename)) != 0)
    {
        ret(result, "配置文件错误", L);
        return result;
    }

    pTrackerServer = tracker_get_connection();
    if (pTrackerServer == NULL)
    {
        fdfs_client_destroy();
        result = errno != 0 ? errno : ECONNREFUSED;
        sprintf(ret_str, "tracker_query_storage fail, " \
            "error no: %d, error info: %s\n", \
            result, STRERROR(result));
        ret(result, ret_str, L);
        return result;
    }

    *group_name = '\0';
    if ((result=tracker_query_storage_store(pTrackerServer, \
                    &storageServer, group_name, &store_path_index)) != 0)
    {
        fdfs_client_destroy();
        ret(result, "tracker_query_storage fail", L);
        return result;
    }

    result = storage_upload_by_filename1(pTrackerServer, \
            &storageServer, store_path_index, \
            local_filename, ext_name, \
            NULL, 0, group_name, file_id);
    if (result == 0)
    {
        ret(result, file_id, L);
    }
    else
    {

        sprintf(ret_str, "upload file fail, " \
            "error no: %d, error info: %s\n", \
            result, STRERROR(result));
        ret(result, ret_str, L);
    }

    tracker_disconnect_server_ex(pTrackerServer, true);
    fdfs_client_destroy();
    return result;
}

/**
* 根据文件路径删除文件
* param char* conf_filename 配置文件
* param
*/
static int delete_file(char *conf_filename, char *file_id, lua_State *L)
{
    ConnectionInfo *pTrackerServer;
    int result;
    char ret_str[512];
    ConnectionInfo storageServer;
    if ((result=fdfs_client_init(conf_filename)) != 0)
    {
        ret(result, "配置文件错误", L);
        return result;
    }

    pTrackerServer = tracker_get_connection();
    if (pTrackerServer == NULL)
    {
        fdfs_client_destroy();
        result = errno != 0 ? errno : ECONNREFUSED;
        sprintf(ret_str, "tracker_query_storage fail, " \
            "error no: %d, error info: %s\n", \
            result, STRERROR(result));
        ret(result, ret_str, L);
        return result;
    }


    if ((result=storage_delete_file1(pTrackerServer, NULL, file_id)) != 0)
    {
        sprintf(ret_str, "delete file fail, " \
            "error no: %d, error info: %s\n", \
            result, STRERROR(result));
        ret(result, ret_str, L);
    }

    if (result == 0)
    {
        ret(result, file_id, L);
    }

    tracker_disconnect_server_ex(pTrackerServer, true);
    fdfs_client_destroy();
    return result;
}

static int fdfs_upload (lua_State *L) {
    char *conf_filename  = (char*)luaL_checkstring(L, 1);
    char *local_filename = (char*)luaL_checkstring(L, 2);
     int ret = upload_file(conf_filename, local_filename, NULL, L);
   return 2;
 }

static int fdfs_upload_ext (lua_State *L) {
    char *conf_filename  = (char*)luaL_checkstring(L, 1);
    char *local_filename = (char*)luaL_checkstring(L, 2);
    char *ext = (char*)luaL_checkstring(L, 3);

     int ret = upload_file(conf_filename, local_filename, ext, L);
    return 2; /* number of results */
 }

static int fdfs_ext(lua_State *L) {
   const char *local_filename = luaL_checkstring(L,1);
   const char *ext_name  = fdfs_get_file_ext_name(local_filename);
   lua_pushstring(L, ext_name);
   return 1;
}


 static int fdfs_delete (lua_State *L) {
    char *conf_filename  = (char*)luaL_checkstring(L, 1);
    char *file_id = (char*)luaL_checkstring(L, 2);
     int ret = delete_file(conf_filename, file_id, L);
   return 2;
 }


static const luaL_Reg mylib[] = {
    {"upload", fdfs_upload },
    {"upload_ext", fdfs_upload_ext },
    {"ext", fdfs_ext},
    {"delete", fdfs_delete},
    {NULL, NULL}  /* 必须以NULL结尾 */
 };

int luaopen_fdfs(lua_State *L) {
    luaL_openlib(L, "upload", mylib, 0);
    return 1;
 }
