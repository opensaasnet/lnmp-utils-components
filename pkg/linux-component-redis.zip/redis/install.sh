#!/bin/bash


#source: http://download.redis.io/releases/redis-6.2.6.tar.gz

_COM_VERSION="redis-6.2.6"
_COM_CONF_FILE="${COM_DATA_CONF_DIR}redis.conf"

com_init "${_COM_VERSION}.tar.gz"
com_untar $COM_SOURCE_FILE

cd $TMP_COM_DIR/$_COM_VERSION
make clean
make && make PREFIX=$COM_INSTALL_DIR install

if [ ! -d "${COM_INSTALL_DIR}bin" ];then
	error "Reids安装失败, make && make install出错!"
fi

createdir $COM_DATA_CONF_DIR
createdir $COM_DATA_DB_DIR
createdir $COM_DATA_LOG_DIR

_wd=${COM_DATA_DB_DIR//\//\\\/}
cp -f "$TMP_COM_DIR$_COM_VERSION/redis.conf" $_COM_CONF_FILE
sed -i "s/daemonize no/daemonize yes/g"  $_COM_CONF_FILE
sed -i "s/supervised no/supervised systemd/g"  $_COM_CONF_FILE
sed -i "s/tcp-keepalive 300/tcp-keepalive 60/g"  $_COM_CONF_FILE
sed -i "s/timeout 0/timeout 300/g"  $_COM_CONF_FILE
sed -i "s/stop-writes-on-bgsave-error yes/stop-writes-on-bgsave-error no/g"  $_COM_CONF_FILE
sed -i "s/rdbchecksum yes/rdbchecksum no/g"  $_COM_CONF_FILE
sed -i "s/dir .\//dir $_wd/g"  $_COM_CONF_FILE
sed -i "s/# maxclients 10000/maxclients 10000/g"  $_COM_CONF_FILE
sed -i "s/# maxmemory <bytes>/maxmemory 4gb/g"  $_COM_CONF_FILE

#supervised no
_COM_SERVICE_FILE=/usr/lib/systemd/system/redis.service
cp -f ${COM_CONF_DIR}redis.service $_COM_SERVICE_FILE
com_replace $_COM_SERVICE_FILE

com_install_test $_COM_SERVICE_FILE

systemctl daemon-reload
systemctl start redis
systemctl stop redis
systemctl start redis   