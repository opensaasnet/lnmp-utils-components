#!/bin/bash


#source https://npm.taobao.org/mirrors/node/v16.0.0/node-v16.0.0-linux-x64.tar.gz
#source: http://download.redis.io/releases/redis-5.0.7.tar.gz

_COM_VERSION="node-v16.0.0-linux-x64"

com_init "${_COM_VERSION}.tar.gz"

com_untar $COM_SOURCE_FILE

cp -r $TMP_COM_DIR$_COM_VERSION/* /usr/local/node/

ln -s /usr/local/node/bin/node /usr/local/bin/node
ln -s /usr/local/node/bin/npm /usr/local/bin/npm
ln -s /usr/local/node/bin/npx /usr/local/bin/npx

#更换国内源
npm config set registry https://registry.npm.taobao.org